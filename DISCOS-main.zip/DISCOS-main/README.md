# DISCOS
Hacking tools for different operating systems. (Linux/Windows/Android)

## Hacking Tools List :
```
Linux Tools : 
  - Boom
  - ChiHULK
  - DDoS-Synflood
  - DDoSim
  - DDos-Attack
  - DDos.pl
  - Davoset
  - Dequiem
  - GoldenEye
  - HULK
  - LOIC
  - Moihack Reloaded
  - Pummel
  - R-U-Dead-Yet
  - RCPnet
  - Refref
  - Simple Python Scripts
  - Slowloris
  - TorDDoS
  - Torshammer
  - pyloris
  
Android Tools :
  - LOIC 
  - OFS DoSer 
```
