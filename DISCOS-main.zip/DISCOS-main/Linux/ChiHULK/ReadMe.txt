*Ethical uses only*

You need to have Python installed for this tool to work/run.

Info:
*******************************************************
ChiHULK sourceforge:
https://sourceforge.net/projects/chihulk-dos-tool/
*******************************************************
Twitter:
https://twitter.com/chinassie
@chinassie
*******************************************************
Facebook:
https://www.facebook.com/profile.php?id=100012934719053
*******************************************************